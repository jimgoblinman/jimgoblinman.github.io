// colors.js
const colors = {
    hyperlinks: '#a80000',
    buttons: '#731010',
    textBody: '#d4d4d4',
    background: '#1f1f1f',
    borders: '#707070',
    textTitles: '#ffffff'
  };
  
  export default colors;
