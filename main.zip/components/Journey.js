import React from 'react';
import styles from '../styles/Journey.module.css';


function Journey() {
/*

<div id="journey" className={styles['journey-box']}>
  <div className={styles['certificats-container']}>
    <div className={styles['item-container']}>
      <p></p>
    </div>
    <div className={styles['item-container']}></div>
    <div className={styles['item-container']}></div>
    <div className={styles['item-container']}></div>
  </div>
</div>
*/
  return (
    <>
    </>
  );
}

export default Journey;  
