const nextConfig = {
  distDir: "build", // Set the custom build output directory
};

module.exports = nextConfig;
